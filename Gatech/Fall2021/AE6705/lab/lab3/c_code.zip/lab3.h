/*
 * lab3.h
 *
 *  Created on: Sep 17, 2021
 *      Author: Tomo
 */

#ifndef LAB3_H_
#define LAB3_H_

#define DEBUG

/*
 * Delay time
 */
void delay(){
    int i;
    for(i = 0; i < 10000; i++){
    }
}

// function prototype
void turnOnOffLED1(uint8_t, uint16_t, uint8_t, uint16_t);

#endif /* LAB3_H_ */
